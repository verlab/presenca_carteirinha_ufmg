#include "storage/attendance_store.h"

#include <ArduinoJson.h>
#include <FS.h>
#include <SD_MMC.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "app/roster.h"
#include "esp32-hal-log.h"

static const char* TAG = "attend";

static constexpr int MAX_PRESENT = ROSTER_MAX_CLASS_STUDENTS;
// The two must agree: present_set() silently drops anyone past MAX_PRESENT, so a
// larger class cap would lose students from every session with no error anywhere.
static_assert(MAX_PRESENT == ROSTER_MAX_CLASS_STUDENTS,
              "attendance capacity must track the class roster cap");
static constexpr int ID_LEN = 20;
static_assert(ID_LEN == sizeof(student_t::id),
              "attendance ids must hold a full student_t::id");
static constexpr long long MINUTE_US = 60000000LL;

static char s_dir[24] = "";
static char s_date[12] = "";
static bool s_open = false;

// Present students in the open session, with their measured minutes (0 when
// unknown — single-tap check-ins). Parallel arrays kept in sync.
static char s_present[MAX_PRESENT][ID_LEN];
static int s_present_min[MAX_PRESENT];
static int s_present_count = 0;

// Timed mode: students who tapped on arrival and have not yet confirmed (the
// "tapin" naming predates the rework — there is no tap-out). Arrivals are also
// persisted to the JSONL as {"tapin":true,"min":N} checkpoint records, so a
// power failure resumes the wait instead of voiding it: on fold the student is
// credited `min` minutes (the monotonic clock resets across a reboot — no RTC —
// so time past the last checkpoint is simply not counted). s_tapin_ckpt is the
// last minute count written to disk, so checkpoints only append on progress.
static char s_tapin_id[MAX_PRESENT][ID_LEN];
static long long s_tapin_us[MAX_PRESENT];
static int s_tapin_ckpt[MAX_PRESENT];
static int s_tapin_count = 0;

static void att_path(const char* dir, const char* date, char* out, size_t cap) {
    snprintf(out, cap, "/classes/%s/attendance/%s.jsonl", dir, date);
}

// --- present set (with minutes) ---------------------------------------------

static int present_find(const char* id) {
    for (int i = 0; i < s_present_count; i++) {
        if (strcmp(s_present[i], id) == 0) return i;
    }
    return -1;
}

// Adds/updates (present) or removes (absent) an id, keeping s_present_min aligned.
static void present_set(const char* id, bool present, int minutes) {
    int f = present_find(id);
    if (present) {
        if (f < 0) {
            if (s_present_count >= MAX_PRESENT) return;
            f = s_present_count++;
            snprintf(s_present[f], ID_LEN, "%s", id);
        }
        s_present_min[f] = minutes;
    } else if (f >= 0) {
        int last = --s_present_count;  // swap-remove
        snprintf(s_present[f], ID_LEN, "%s", s_present[last]);
        s_present_min[f] = s_present_min[last];
    }
}

// --- in-progress tap-in set -------------------------------------------------

static int tapin_find(const char* id) {
    for (int i = 0; i < s_tapin_count; i++) {
        if (strcmp(s_tapin_id[i], id) == 0) return i;
    }
    return -1;
}

static void tapin_remove(int f) {
    int last = --s_tapin_count;  // swap-remove
    snprintf(s_tapin_id[f], ID_LEN, "%s", s_tapin_id[last]);
    s_tapin_us[f] = s_tapin_us[last];
    s_tapin_ckpt[f] = s_tapin_ckpt[last];
}

// `ckpt_min` is the minute count already on disk for this arrival (0 for a
// fresh tap, the credited minutes for one restored by the fold).
static void tapin_add(const char* id, long long us, int ckpt_min) {
    if (s_tapin_count >= MAX_PRESENT) return;
    int i = s_tapin_count++;
    snprintf(s_tapin_id[i], ID_LEN, "%s", id);
    s_tapin_us[i] = us;
    s_tapin_ckpt[i] = ckpt_min;
}

// --- history count cache ----------------------------------------------------
//
// attendance_present_for() folds an entire JSONL, and the class screens ask for
// every past date at once: the session picker lists them, the history view lists
// them again, and the statistics screen averages them. Without memoising, one
// class with 24 sessions costs 24 file reads per screen build, on the LVGL
// thread, over and over.
//
// One class is cached at a time (the screens only ever show one). Entries are
// dropped by the writes below, so a count can never go stale from anything this
// module does. It CAN go stale if the file is edited behind our back — only the
// debug WiFi file editor does that, and it calls attendance_history_cache_clear().
static constexpr int CACHE_MAX = 24;  // matches the class screen's MAX_DATES
static char s_cache_dir[24] = "";
static char s_cache_date[CACHE_MAX][12];
static int s_cache_count[CACHE_MAX];
static int s_cache_n = 0;

static bool cache_is(const char* dir) { return s_cache_dir[0] && strcmp(s_cache_dir, dir) == 0; }

static void cache_flush(void) {
    s_cache_dir[0] = '\0';
    s_cache_n = 0;
}

static bool cache_get(const char* dir, const char* date, int* out) {
    if (!cache_is(dir)) return false;
    for (int i = 0; i < s_cache_n; i++) {
        if (strcmp(s_cache_date[i], date) == 0) {
            *out = s_cache_count[i];
            return true;
        }
    }
    return false;
}

static void cache_put(const char* dir, const char* date, int count) {
    if (!cache_is(dir)) {  // a different class: start its cache from scratch
        cache_flush();
        snprintf(s_cache_dir, sizeof(s_cache_dir), "%s", dir);
    }
    if (s_cache_n >= CACHE_MAX) return;  // the screens never ask for more
    snprintf(s_cache_date[s_cache_n], 12, "%s", date);
    s_cache_count[s_cache_n] = count;
    s_cache_n++;
}

// One date changed on disk; the next read re-folds it.
static void cache_drop(const char* dir, const char* date) {
    if (!cache_is(dir)) return;
    for (int i = 0; i < s_cache_n; i++) {
        if (strcmp(s_cache_date[i], date) == 0) {
            int last = --s_cache_n;  // swap-remove
            snprintf(s_cache_date[i], 12, "%s", s_cache_date[last]);
            s_cache_count[i] = s_cache_count[last];
            return;
        }
    }
}

void attendance_history_cache_clear(void) { cache_flush(); }

// --- generic present-only fold (history counts) -----------------------------

static void set_apply(char set[][ID_LEN], int* count, const char* id, bool present) {
    int found = -1;
    for (int i = 0; i < *count; i++) {
        if (strcmp(set[i], id) == 0) {
            found = i;
            break;
        }
    }
    if (present && found < 0 && *count < MAX_PRESENT) {
        snprintf(set[(*count)++], ID_LEN, "%s", id);
    } else if (!present && found >= 0) {
        snprintf(set[found], ID_LEN, "%s", set[*count - 1]);  // swap-remove
        (*count)--;
    }
}

static bool fold_file(const char* path, char set[][ID_LEN], int* count) {
    *count = 0;
    if (!SD_MMC.exists(path)) return true;
    File f = SD_MMC.open(path, FILE_READ);
    if (!f) return false;
    size_t sz = f.size();
    char* buf = (char*)malloc(sz + 1);
    if (!buf) {
        f.close();
        return false;
    }
    size_t n = f.readBytes(buf, sz);
    buf[n] = '\0';
    f.close();

    // One document reused across every line: deserializeJson() clears it, and
    // hoisting it out keeps the allocator's blocks instead of building and
    // tearing one down per record. A busy session is hundreds of lines.
    JsonDocument doc;
    char* save = nullptr;
    for (char* line = strtok_r(buf, "\n", &save); line; line = strtok_r(nullptr, "\n", &save)) {
        if (line[0] != '{') continue;
        if (deserializeJson(doc, line)) continue;
        const char* id = doc["id"] | "";
        bool present = doc["present"] | false;
        if (id[0]) set_apply(set, count, id, present);
    }
    free(buf);
    return true;
}

// Folds the open session's file into s_present / s_present_min and the tap-in
// set (last record per id wins, carrying its "min"). A trailing tapin record
// restores the arrival as in-progress, credited with the checkpointed minutes:
// its reference timestamp is back-dated to `now_us - min`, so the countdown
// resumes where the last checkpoint left it.
static bool fold_open(const char* path, long long now_us) {
    s_present_count = 0;
    s_tapin_count = 0;
    if (!SD_MMC.exists(path)) return true;
    File f = SD_MMC.open(path, FILE_READ);
    if (!f) return false;
    size_t sz = f.size();
    char* buf = (char*)malloc(sz + 1);
    if (!buf) {
        f.close();
        return false;
    }
    size_t n = f.readBytes(buf, sz);
    buf[n] = '\0';
    f.close();

    JsonDocument doc;  // reused per line; see fold_file
    char* save = nullptr;
    for (char* line = strtok_r(buf, "\n", &save); line; line = strtok_r(nullptr, "\n", &save)) {
        if (line[0] != '{') continue;
        if (deserializeJson(doc, line)) continue;
        const char* id = doc["id"] | "";
        bool present = doc["present"] | false;
        int minutes = doc["min"] | 0;
        bool tapin = doc["tapin"] | false;
        if (!id[0]) continue;
        int t = tapin_find(id);
        if (t >= 0) tapin_remove(t);  // any later record supersedes the arrival
        if (tapin) {
            present_set(id, false, 0);
            tapin_add(id, now_us - (long long)minutes * MINUTE_US, minutes);
        } else {
            present_set(id, present, minutes);
        }
    }
    free(buf);
    return true;
}

// Formats one JSONL record, optionally with the "min" field. `tapin` marks an
// arrival checkpoint (in progress, not a presence): {"present":false,
// "min":N,"tapin":true}, where N is the minutes waited so far.
static int format_record(char* line, size_t cap, const char* id, bool present, int minutes,
                         bool with_min, bool tapin) {
    if (tapin) {
        return snprintf(line, cap, "{\"id\":\"%s\",\"present\":false,\"min\":%d,\"tapin\":true}\n",
                        id, minutes);
    }
    if (with_min) {
        return snprintf(line, cap, "{\"id\":\"%s\",\"present\":%s,\"min\":%d}\n", id,
                        present ? "true" : "false", minutes);
    }
    return snprintf(line, cap, "{\"id\":\"%s\",\"present\":%s}\n", id, present ? "true" : "false");
}

// Ensures the attendance dir exists and opens the open session's file for
// append (invalid File on failure, already logged).
static File open_for_append(void) {
    char adir[64];
    snprintf(adir, sizeof(adir), "/classes/%s/attendance", s_dir);
    if (!SD_MMC.exists(adir)) SD_MMC.mkdir(adir);

    char path[80];
    att_path(s_dir, s_date, path, sizeof(path));
    File f = SD_MMC.open(path, FILE_APPEND, true);
    if (!f) ESP_LOGE(TAG, "append open failed: %s", path);
    return f;
}

// Appends one JSONL record (see format_record for the shapes).
static bool append_record(const char* id, bool present, int minutes, bool with_min,
                          bool tapin = false) {
    File f = open_for_append();
    if (!f) return false;
    char line[96];
    int len = format_record(line, sizeof(line), id, present, minutes, with_min, tapin);
    size_t w = f.write((const uint8_t*)line, len);
    f.close();
    // The day's fold just changed; drop any memoised count for it.
    cache_drop(s_dir, s_date);
    return w == (size_t)len;
}

// --- session ----------------------------------------------------------------

bool attendance_open(const char* class_dir, const char* date, long long now_us) {
    attendance_close();
    snprintf(s_dir, sizeof(s_dir), "%s", class_dir);
    snprintf(s_date, sizeof(s_date), "%s", date);
    s_open = true;

    char path[80];
    att_path(class_dir, date, path, sizeof(path));
    bool ok = fold_open(path, now_us);
    ESP_LOGI(TAG, "open %s %s: %d present, %d in progress%s", class_dir, date, s_present_count,
             s_tapin_count, ok ? "" : " (read error)");
    return ok;
}

bool attendance_is_open(void) { return s_open; }
const char* attendance_dir(void) { return s_open ? s_dir : ""; }
const char* attendance_date(void) { return s_open ? s_date : ""; }
bool attendance_is_present(const char* id) { return present_find(id) >= 0; }
int attendance_present_count(void) { return s_present_count; }

bool attendance_set(const char* id, bool present) {
    if (!s_open || !id || !id[0]) return false;
    // A manual override clears any in-progress timing for this student.
    int t = tapin_find(id);
    if (t >= 0) tapin_remove(t);
    present_set(id, present, 0);
    return append_record(id, present, 0, false);
}

// Whole minutes still to wait, rounded up so a student is never told "0 min"
// while the threshold is not actually met yet.
static int remaining_min(long long elapsed_us, int threshold_min) {
    long long need = (long long)threshold_min * MINUTE_US - elapsed_us;
    if (need <= 0) return 0;
    return (int)((need + MINUTE_US - 1) / MINUTE_US);
}

// Microseconds since the arrival tap at index `t`, clamped at 0 (a monotonic
// clock shouldn't go backwards, but a bad `now_us` must not underflow).
static long long tapin_elapsed(int t, long long now_us) {
    long long e = now_us - s_tapin_us[t];
    return e < 0 ? 0 : e;
}

att_state_t attendance_tap(const char* id, long long now_us, int threshold_min) {
    att_state_t r = {ATT_ABSENT, 0, 0, true};
    if (!s_open || !id || !id[0]) return r;

    int p = present_find(id);
    if (p >= 0) {  // registered already — this tap is ignored
        r.status = ATT_ALREADY_PRESENT;
        r.minutes = s_present_min[p];
        return r;
    }

    int t = tapin_find(id);
    if (t < 0) {  // first tap: record arrival, in RAM and on disk
        tapin_add(id, now_us, 0);
        r.status = ATT_IN_PROGRESS;
        r.remaining = remaining_min(0, threshold_min);
        // The arrival record is what lets a power failure resume the wait
        // instead of silently voiding it; an unsaved arrival still works for
        // this session, but the caller must surface that it would not survive.
        r.saved = append_record(id, false, 0, false, true);
        return r;
    }

    long long elapsed = tapin_elapsed(t, now_us);
    int minutes = (int)(elapsed / MINUTE_US);
    if (minutes < threshold_min) {
        // Too soon to register — the arrival stands, so the student can tap
        // again later. Refresh the on-disk checkpoint with the progress so far
        // (best effort: on failure the previous checkpoint still stands).
        if (minutes > s_tapin_ckpt[t] && append_record(id, false, minutes, false, true)) {
            s_tapin_ckpt[t] = minutes;
        }
        r.status = ATT_TOO_EARLY;
        r.minutes = minutes;
        r.remaining = remaining_min(elapsed, threshold_min);
        return r;
    }

    // Threshold met: register the presence and close out the arrival. The append
    // result is carried out to the caller — RAM says present either way, so this
    // flag is the only thing that can tell the student it did not reach the card.
    tapin_remove(t);
    present_set(id, true, minutes);
    r.saved = append_record(id, true, minutes, true);
    r.status = ATT_PRESENT;
    r.minutes = minutes;
    return r;
}

att_state_t attendance_tap_state(const char* id, long long now_us, int threshold_min) {
    att_state_t r = {ATT_ABSENT, 0, 0, true};
    if (!s_open || !id || !id[0]) return r;
    int t = tapin_find(id);
    if (t >= 0) {
        long long elapsed = tapin_elapsed(t, now_us);
        r.status = ATT_IN_PROGRESS;
        r.minutes = (int)(elapsed / MINUTE_US);
        r.remaining = remaining_min(elapsed, threshold_min);
        return r;
    }
    int p = present_find(id);
    if (p >= 0) {
        r.status = ATT_PRESENT;
        r.minutes = s_present_min[p];
    }
    return r;
}

int attendance_checkpoint(long long now_us) {
    if (!s_open || s_tapin_count == 0) return 0;

    // One open/write/close for the whole batch: this runs on the LVGL thread,
    // and each per-record cycle costs a FatFs metadata round-trip — a full
    // lecture hall mid-wait would turn per-record appends into a visible stall.
    // The file is opened lazily so a tick where nobody advanced writes nothing.
    File f;
    int wrote = 0;
    for (int i = 0; i < s_tapin_count; i++) {
        int minutes = (int)(tapin_elapsed(i, now_us) / MINUTE_US);
        if (minutes <= s_tapin_ckpt[i]) continue;  // no whole-minute progress
        if (!f) {
            f = open_for_append();
            if (!f) return 0;
        }
        char line[96];
        int len = format_record(line, sizeof(line), s_tapin_id[i], false, minutes, false, true);
        if (f.write((const uint8_t*)line, len) != (size_t)len) continue;
        s_tapin_ckpt[i] = minutes;
        wrote++;
    }
    if (f) f.close();
    if (wrote > 0) cache_drop(s_dir, s_date);
    return wrote;
}

void attendance_close(void) {
    s_open = false;
    s_dir[0] = '\0';
    s_date[0] = '\0';
    s_present_count = 0;
    s_tapin_count = 0;
}

int attendance_list_dates(const char* class_dir, char dates[][12], int max) {
    char adir[64];
    snprintf(adir, sizeof(adir), "/classes/%s/attendance", class_dir);
    File d = SD_MMC.open(adir);
    if (!d || !d.isDirectory()) {
        if (d) d.close();
        return 0;
    }

    int n = 0;
    File e;
    while (n < max && (e = d.openNextFile())) {
        const char* name = e.name();  // basename on this core (see photo_store)
        size_t len = strlen(name);
        if (len == 16 && strcmp(name + 10, ".jsonl") == 0) {
            snprintf(dates[n], 12, "%.10s", name);
            n++;
        }
        e.close();
    }
    d.close();

    // Newest first; "YYYY-MM-DD" sorts lexically == chronologically.
    for (int i = 1; i < n; i++) {
        char key[12];
        snprintf(key, sizeof(key), "%s", dates[i]);
        int j = i;
        while (j > 0 && strcmp(dates[j - 1], key) < 0) {
            snprintf(dates[j], 12, "%s", dates[j - 1]);
            j--;
        }
        snprintf(dates[j], 12, "%s", key);
    }
    return n;
}

int attendance_present_for(const char* class_dir, const char* date) {
    int cached = 0;
    if (cache_get(class_dir, date, &cached)) return cached;

    // Heap, not a static: 2 KB of the internal pool (the scarce one — see
    // BACKLOG.md) held permanently for a fold that is memoised anyway, so on the
    // common path it is not even reached. Too small to force PSRAM, but it is
    // transient either way — and off the stack, which is the point.
    char (*tmp)[ID_LEN] = (char(*)[ID_LEN])malloc(sizeof(char[MAX_PRESENT][ID_LEN]));
    if (!tmp) {
        ESP_LOGE(TAG, "present_for %s %s: out of memory", class_dir, date);
        return 0;  // not cached: a memory blip must not become a sticky wrong count
    }
    int count = 0;
    char path[80];
    att_path(class_dir, date, path, sizeof(path));
    bool ok = fold_file(path, tmp, &count);
    free(tmp);
    // Only memoise a count we actually managed to read; caching a 0 from a
    // failed read would make it stick until something invalidated the entry.
    if (ok) cache_put(class_dir, date, count);
    return count;
}

int attendance_clear(const char* class_dir, int* out_failed, progress_cb_t cb, void* ctx) {
    attendance_close();  // never leave a session open on files we're deleting
    if (cache_is(class_dir)) cache_flush();
    // List the dates first, then delete — removing files while iterating the
    // directory would be unsafe. Heap, not a static: this is a debug-only wipe,
    // and 6 KB is the single largest reclaimable block in the internal pool that
    // BACKLOG.md calls constrained. Over 4 KB, so it lands in PSRAM.
    static constexpr int MAX_CLEAR_DATES = 512;
    char (*dates)[12] = (char(*)[12])malloc(sizeof(char[MAX_CLEAR_DATES][12]));
    if (!dates) {
        ESP_LOGE(TAG, "clear %s: out of memory listing sessions", class_dir);
        if (out_failed) *out_failed = -1;  // "unknown", not "none failed"
        return 0;
    }
    int n = attendance_list_dates(class_dir, dates, MAX_CLEAR_DATES);
    int removed = 0;
    for (int i = 0; i < n; i++) {
        char path[80];
        att_path(class_dir, dates[i], path, sizeof(path));
        if (SD_MMC.remove(path)) {
            removed++;
        } else {
            // Silently dropping this is how a partial wipe used to look clean.
            ESP_LOGE(TAG, "clear %s: could not delete %s", class_dir, path);
        }
        // Report attempts, not successes: the point is that the wipe is moving,
        // and a file that resisted still consumed the time.
        if (cb) {
            progress_t p = {"Deleting attendance", dates[i], i + 1, n};
            cb(&p, ctx);
        }
    }
    free(dates);
    if (out_failed) *out_failed = n - removed;
    return removed;
}
